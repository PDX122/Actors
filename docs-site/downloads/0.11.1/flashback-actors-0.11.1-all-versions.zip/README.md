# Flashback Actors 0.11.1 release candidate

Nine version-specific JARs are included. Install the matching Minecraft JAR alongside Flashback and the required Fabric dependencies. The 26.1 target uses Minecraft 26.1.2.

Validated: all nine native replay clients, 4,644 unit tests, eight GPU tests, recording and sharing roundtrips, all fourteen camera modes in real H.264 exports, and screenshot/animation/catalog checks. A real ReplayMod format 14 recording was also converted and exercised through playback, recording, export and the visual sweep. Supplemental 1.21.1, 26.2 and 26.3 exports verify the corrected end boundary with 56 decoded frames.

SHA256SUMS.txt verifies the nine JARs. QA-report.md and test-summary.json summarize the evidence. Full captures, logs and the comparison gallery remain in build/release-batches/production-final in the development checkout.

Coverage limits: physical microphone capture, audible output, authenticated online skin requests, and complete mouse/keyboard gesture tests remain external checks. Automated handlers and representative visual inspection do not establish those outcomes. Arbitrary third-party models, shaders and mod combinations are outside this matrix.

ReplayMod conversion validates the complete stream before writing. Unsupported signed chat, relative teleports, custom payload channels and movement schemas return an explanation. Only the real same-version 26.2 import fixture has full runtime conversion coverage; protocol-state and movement tests run on every target.

Morph library world stability: the 26.2 and 26.3 previews now use private feature renderers and staged vertex buffers. Both clients passed a repeated 12-frame world capture check with the library open. The latest cross-version unit run contains 4,644 passing tests.
